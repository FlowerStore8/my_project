package flowerstore;

public class WrongData extends Exception{

    public WrongData(String message){
        super(message);

    }
}
