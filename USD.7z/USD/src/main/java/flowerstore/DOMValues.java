package flowerstore;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

public class DOMValues {

    private static ArrayList currencies = new ArrayList();

    public static ArrayList<Currency> read(String file) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();


        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(file)));

        NodeList names = document.getElementsByTagName("Name");
        NodeList nominals = document.getElementsByTagName("Nominal");
        NodeList values = document.getElementsByTagName("Value");
        NodeList charCodes = document.getElementsByTagName("CharCode");

        ArrayList<Currency> currencies = new ArrayList<Currency>();

        for(int i = 0; i < names.getLength(); i++){
            String name = names.item(i).getTextContent();
            String nominal = nominals.item(i).getTextContent();
            String value = values.item(i).getTextContent();
            String charCode = charCodes.item(i).getTextContent();
            currencies.add(new Currency(name, value, nominal, charCode));
        }

        return currencies;

    }

}
