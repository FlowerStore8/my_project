package flowerstore;
import kong.unirest.Unirest;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static  void main (String [] args) throws IOException,
            SAXException, ParserConfigurationException, WrongData {
        Scanner in = new Scanner(System.in);
        System.out.println("Date(YYYY-MM-DD: ");
        String date = in.next();
        String wrong = "Дата введена неправильно, правильный формат: YYYY-MM-DD";
        try {
            String[] dates = date.split("-");
            if (dates[0].length()<4){
                throw new WrongData(wrong);
            }
            if(dates[1].length()<2){
                throw new WrongData(wrong);
            }
            if (dates[2].length()<2){
                throw new WrongData(wrong);
            }
            date = dates[2] + "/" + dates[1] + "/" + dates[0];
        } catch (Exception ex){
            System.out.println();
        }
        System.out.println("ID: ");
        String id = in.next();
        System.out.println("file: ");
        String file = in.next();
        String response = Unirest.get("http://www.cbr.ru/" +
                "scripts/XML_daily.asp?date_req={date}")
                .routeParam("date", date)
                .asString()
                .getBody();
        ArrayList<Currency> currencies = DOMValues.read(response);
        String result = "";
        for(Currency currency : currencies){
            if(currency.getCharCode().equals(id)){
                result = currency.getNominal()+ " "+
                        currency.getName()+" = "+
                        currency.getValue() + " Российских рубля\n";
                break;
            }
        }
        if(result.equals("")){
            throw new WrongData("Данные введены неправильно");
        }
        else {
            FileWorker.write(file, result);
        }
    }

}
