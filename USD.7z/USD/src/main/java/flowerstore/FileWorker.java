package flowerstore;

import java.io.FileWriter;
import java.io.IOException;

class FileWorker {

    public static void write(String file, String out){
        FileWriter writer = null;
        try {
            writer = new FileWriter(file, true);
            writer.write(out);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

}
