package flowerstore;

public class Currency {

    private String name;
    private String value;
    private String charCode;
    private String nominal;

    Currency(String name, String value, String nominal, String charCode){
        this.name = name;
        this.value = value;
        this.nominal = nominal;
        this.charCode = charCode;
    }

    public String getName() {
        return name;
    }

    public String getNominal() {
        return nominal;
    }

    public String getValue() {
        return value;
    }

    public String getCharCode() {
        return charCode;
    }
}
